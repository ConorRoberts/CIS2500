#include "functions.h"

int *create_freq_table(char *str){
  int *counts=calloc(26,sizeof(int));
  return counts;
}
