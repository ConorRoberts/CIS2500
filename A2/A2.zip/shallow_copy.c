#include "funcs.h"

struct Double_Array *shallow_copy(struct Double_Array *ptr){
  struct Double_Array *ret=ptr;
  return ret;
}
