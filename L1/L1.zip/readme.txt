Author: Conor Roberts
Date Created: January 14th, 2020
Purpose: To take in lines of words entered by a user and output a count of words and lines.
Usage: Compile and run. Enter words as prompted. Exit with a '.' on a new line.
