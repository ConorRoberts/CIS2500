#include "Sorted_List.h"
#include "Commands.h"

/*functions should take this general form with some extra details*/
    /*Call sorted_list function*/
    /*Call print_key_value_pair on the values*/

void rem_first (Sorted_List * list) {
    return;
}

void rem_last (Sorted_List * list) {
    return;
}

void rem_small (Sorted_List * list) {
    return;
}

void rem_large (Sorted_List * list) {
    return;
}


void empty (Sorted_List * list) {
    return;
}
