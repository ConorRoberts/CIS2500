Creates a foobarbaz array
Swaps two random values in the array
Prints the array
Compile & run with: make & ./main
